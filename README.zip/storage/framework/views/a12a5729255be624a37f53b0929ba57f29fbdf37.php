
<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Approval Order to Asset</h1>
</div>
<!-- Grid row -->
<!-- karena menggunakan resource pada routes nya, gabungan /dashboard + method post pasti akan ke store -->
<form action="/transaction/<?php echo e($transactions[0]->order_id); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="card col-6 mb-3">
        <div class="row m-lg-1">
            <!-- Grid column -->

            <div class="col-8 mt-2">
                <!-- Default input -->
                <label class="mb-2">Order to Asset</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="asset_id" name="asset_id" disabled autofocus>

                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('asset_id', $ast->asset_id)==$ast->asset_id): ?>
                    <option value="<?= $ast->asset_id; ?>" selected><?= $ast->asset_name; ?></option>
                    <?php else: ?>
                    <option value="<?= $ast->asset_id; ?>"><?= $ast->asset_name; ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Ordered By</label>
                <input class="form-control" id="order_user" name="order_user" disabled value="<?php echo e($user_order->name); ?>"></input>
            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->

            <div class="col-8 mt-2">
                <!-- Default input -->
                <label class="mb-2">Purpose in ordering Asset</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="purpose_id" name="purpose_id" disabled autofocus>

                    <?php $__currentLoopData = $purposes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('purpose_id', $prp->id)==$prp->id): ?>
                    <option value="<?= $prp->id; ?>" selected><?= $prp->purpose_name; ?></option>
                    <?php else: ?>
                    <option value="<?= $prp->id; ?>"><?= $prp->purpose_name; ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Purpose Detail</label>
                <input class="form-control <?php $__errorArgs = ['purpose_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="purpose_desc" name="purpose_desc" disabled value="<?php echo e(old('purpose_desc',$transactions[0]->purpose_desc)); ?>"></input>
                <?php $__errorArgs = ['purpose_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class=" invalid-feedback"><?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-4 mt-2">

                <label>Order At</label>
                <input id="order_at" type="text" class="form-control <?php $__errorArgs = ['order_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Return Date" name="order_at" disabled value="<?php echo e(old('order_at',$transactions[0]->order_at)); ?>">
                <?php $__errorArgs = ['order_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-4 mt-2">

                <label>Estimate Asset Return</label>
                <input id="estimate_return_at" type="text" class="form-control <?php $__errorArgs = ['estimate_return_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Return Date" name="estimate_return_at" disabled value="<?php echo e(old('estimate_return_at',$transactions[0]->estimate_return_at)); ?>">
                <?php $__errorArgs = ['estimate_return_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <h5 class="mt-3">Approval Log</h5>


            <?php if(!empty($user_adm)): ?>
            <!-- Admin Cek sudah cek-->
            <div class="col-12 mt-3">
                <label id="adm_user_id" name="" value="" style="background-color: greenyellow;">Admin Check by <?php echo e($user_adm->name); ?> at <?php echo e($transactions[0]->adm_at); ?></label>
            </div>
            <div class="col-10 mt-1">
                <label for="adm_note">Note:</label>
                <input type="text" id="adm_note" name="adm_note" class="form-control" placeholder="Note From Admin" disabled value="<?php echo e($transactions[0]->adm_note); ?>">
            </div>

            <?php elseif(empty($user_adm) and empty($user_app) and empty($user_return[0])): ?>
            <!-- Admin ketika belum cek Cek -->
            <div class="col-12 mt-3">
                <label id="" name="" value="">-->Waiting For Admin Check</label>
            </div>
            <div class="col-10 mt-1">
                <label for="adm_note">Note:</label>
                <input type="text" id="adm_note" name="adm_note" class="form-control" placeholder="Note From Admin" disabled value="">
            </div>

            <?php endif; ?>
            <!-- Admin ketika belum cek Cek -->


            <!-- who approval -->
            <?php if(!empty($user_app) && empty($user_disapp)): ?>
            <div class="col-12 mt-4">
                <label id="adm_user_id" name="" value="" style="background-color: greenyellow;">Approved by <?php echo e($user_app->name); ?> at <?php echo e($transactions[0]->app_at); ?></label>
            </div>

            <div class="col-10 mt-1">
                <label for="app_note">Note:</label>
                <input type="text" id="app_note" name="app_note" class="form-control" placeholder="Note From Approval" disabled value="<?php echo e($transactions[0]->app_note); ?>">
            </div>
            <?php elseif(empty($user_app) && !empty($user_disapp)): ?>
            <div class="col-12 mt-4">
                <label id="adm_user_id" name="" value="" style="background-color:orangered;">Disapproved by <?php echo e($user_disapp->name); ?> at <?php echo e($transactions[0]->disapp_at); ?></label>
            </div>

            <div class="col-10 mt-1">
                <label for="app_note">Note:</label>
                <input type="text" id="app_note" name="app_note" class="form-control" placeholder="Note From Approval" disabled value="<?php echo e($transactions[0]->disapp_note); ?>">
            </div>

            <?php else: ?>
            <div class="col-12 mt-4">
                <label id="" name="" value="">-->Waiting For Approval</label>
            </div>
            <div class="col-10 mt-1">
                <label for="app_note">Note:</label>
                <input type="text" id="app_note" name="app_note" class="form-control" placeholder="Note From Approval" value="" disabled>
            </div>
            <?php endif; ?>
            <!-- who approval -->

            <!-- returning -->
            <?php if(empty($user_return)): ?>
            <div class="col-12 mt-4">
                <label id="" name="" value="">-->Waiting For Admin Check</label>
            </div>
            <div class="col-10 mt-1">
                <label for="return_note">Note:</label>
                <input type="text" id="return_note" name="return_note" class="form-control" placeholder="Note From Admin" value="" disabled>
            </div>
            <?php elseif(!empty($user_return)): ?>
            <div class="col-12 mt-4">
                <label id="" name="" value="" style="background-color:greenyellow;">Received by <?php echo e($user_return->name); ?> at <?php echo e($transactions[0]->return_at); ?></label>
            </div>
            <div class="col-10 mt-1">
                <label for="return_note">Note:</label>
                <input type="text" id="return_note" name="return_note" class="form-control" placeholder="Note From Admin" value="<?php echo e($transactions[0]->return_note); ?>" disabled>
            </div>
            <?php endif; ?>
            <!--==================== batas show blade=============================== -->


        </div>

    </div>
</form>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Larapps\ymm\resources\views/transaction/show.blade.php ENDPATH**/ ?>