

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Add Assets</h1>
</div>
<!-- Grid row -->
<!-- karena menggunakan resource pada routes nya, gabungan /dashboard + method post pasti akan ke store -->
<form action="/dashboard" method="post">
    <?php echo csrf_field(); ?>
    <div class="card col-6 mb-3">
        <div class="card-header">Please Fill Form</div>
        <div class="row m-lg-1">
            <!-- Grid column -->

            <div class="col-8 mt-2">
                <!-- Default input -->
                <label class="mb-2">Input Asset Type</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="type_id" name="type_id" required autofocus>

                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('type_id')==$ty->id): ?>
                    <option value="<?= $ty->id; ?>" selected><?= $ty->asset_type_name; ?></option>
                    <?php else: ?>
                    <option value="<?= $ty->id; ?>"><?= $ty->asset_type_name; ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

        </div>

        <!-- Small input -->
        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Name</label>
                <input type="text" class="form-control <?php $__errorArgs = ['asset_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Your Asset Name" id="asset_name" name="asset_name" required value="<?php echo e(old('asset_name')); ?>">
                <?php $__errorArgs = ['asset_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Price, If been bought (IDR)</label>
                <input type="text" class="form-control" placeholder="Price of Asset" id="asset_idr_str" name="asset_idr_str" value="">
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Desc</label>
                <input class="form-control <?php $__errorArgs = ['asset_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="asset_desc" name="asset_desc" rows="3" required value="<?php echo e(old('asset_desc')); ?>"></input>
                <?php $__errorArgs = ['asset_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class=" invalid-feedback"><?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Couse Of Existance</label>
                <input class="form-control <?php $__errorArgs = ['couse_exist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="couse_exist" name="couse_exist" rows="3" required value="<?php echo e(old('couse_exist')); ?>"></input>
                <?php $__errorArgs = ['couse_exist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-4 mt-2">

                <label>Asset Added Date</label>
                <input id="added_at" type="text" class="form-control <?php $__errorArgs = ['added_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Added Date" name="added_at" required value="<?php echo e(old('added_at')); ?>">
                <?php $__errorArgs = ['added_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-4 mt-2">
                <label>Asset Expired Date</label>
                <!-- <input id="datepickers" class="form-control form-control-sm" type="text" placeholder="Expired Date"> -->
                <input id="expired_date" type="text" class="form-control" placeholder="Expired Date" name="expired_date" value="<?php echo e(old('expired_date')); ?>">

            </div>
        </div>

        <div class="row m-lg-1">
            <div class="col-8 mt-2">
                <!-- Default input -->
                <label class="mb-2">Asset Status</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="status_id" name="status_id" required>

                    <?php $__currentLoopData = $asset_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('status_id') == $stat->id): ?>
                    <option value="<?= $stat->id; ?>" selected><?= $stat->asset_status_name; ?></option>
                    <?php else: ?>
                    <option value="<?= $stat->id; ?>"><?= $stat->asset_status_name; ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>

        <div class="row m-lg-1">
            <div class="col-8 mt-2">
                <!-- Default input -->
                <label class="mb-2">Asset Location</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="location_id" name="location_id" required>

                    <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('location_id')==$loc->id): ?>
                    <option value="<?= $loc->id; ?>" selected><?= $loc->asset_HL_LL; ?>-<?= $loc->asset_loc_mp; ?>-<?= $loc->asset_loc_dkm; ?>- Room <?= $loc->asset_loc_dkm_room; ?></option>
                    <?php else: ?>
                    <option value="<?= $loc->id; ?>"><?= $loc->asset_HL_LL; ?>-<?= $loc->asset_loc_mp; ?>-<?= $loc->asset_loc_dkm; ?>- Room <?= $loc->asset_loc_dkm_room; ?></option>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>

        <div class="row m-lg-1">
            <div class="col mt-2">
                <label>Please provide MIS Id, If any</label>

            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-1">
                <input type="number" class="form-control <?php $__errorArgs = ['mis_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Asset MIS Id" id="mis_id" name="mis_id" value="<?php echo e(old('mis_id')); ?>">
                <?php $__errorArgs = ['mis_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row m-lg-1">
            <div class="col-8 mt-3 mb-2">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </div>

    <input type="number" class="form-control" placeholder="Your Asset Price" id="asset_price" name="asset_price" hidden>

</form>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Larapps\ymm\resources\views/dashboard/create.blade.php ENDPATH**/ ?>