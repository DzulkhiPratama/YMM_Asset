

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Asset Detail</h1>
</div>
<!-- Grid row -->
<!-- karena menggunakan resource pada routes nya, gabungan /dashboard + method post pasti akan ke store -->
<form action="/dashboard/<?php echo e($assety[0]->asset_id); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="card col-6 mb-3">
        <div class="row m-lg-1">
            <!-- Grid column -->

            <div class="col-8 mt-2">
                <!-- Default input -->
                <label class="mb-2">Input Asset Type</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="type_id" name="type_id" disabled>

                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('type_id', $assety[0]->type_id)==$ty->id): ?>
                    <option value="<?= $ty->id; ?>" selected><?= $ty->asset_type_name; ?></option>
                    <?php else: ?>
                    <option value="<?= $ty->id; ?>"><?= $ty->asset_type_name; ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

        </div>

        <!-- Small input -->
        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Name</label>
                <input type="text" class="form-control <?php $__errorArgs = ['asset_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Your Asset Name" id="asset_name" name="asset_name" disabled value="<?php echo e(old('asset_name', $assety[0]->asset_name)); ?>">
                <?php $__errorArgs = ['asset_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Small input -->
        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>PIC</label>
                <input type="text" class="form-control" placeholder="Your Asset Name" id="pic_name" name="pic_name" disabled value="<?php echo e($pic->name); ?>">
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>PIC ID</label>
                <input type="text" class="form-control" placeholder="Your Asset Name" id="pic_id" name="pic_id" disabled value="<?php echo e($pic->userid); ?>">
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Price, If been bought (IDR)</label>
                <input type="text" class="form-control" placeholder="Your Asset Price" id="asset_price_str" name="asset_price_str" value="" disabled>
            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Desc</label>
                <input class="form-control <?php $__errorArgs = ['asset_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="asset_desc" name="asset_desc" rows="3" disabled value="<?php echo e(old('asset_desc',$assety[0]->asset_desc)); ?>"></input>
                <?php $__errorArgs = ['asset_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class=" invalid-feedback"><?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-2">
                <label>Asset Couse Of Existance</label>
                <input class="form-control <?php $__errorArgs = ['couse_exist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="couse_exist" name="couse_exist" rows="3" disabled value="<?php echo e(old('couse_exist',$assety[0]->couse_exist)); ?>"></input>
                <?php $__errorArgs = ['couse_exist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-4 mt-2">

                <label>Asset Added Date</label>
                <input id="added_at" type="text" class="form-control <?php $__errorArgs = ['added_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Added Date" name="added_at" disabled value="<?php echo e(old('added_at',$assety[0]->added_at)); ?>">
                <?php $__errorArgs = ['added_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-4 mt-2">
                <label>Asset Expired Date</label>
                <!-- <input id="datepickers" class="form-control form-control-sm" type="text" placeholder="Expired Date"> -->
                <input id="expired_date" type="text" class="form-control" placeholder="Expired Date" name="expired_date" value="<?php echo e(old('expired_date',$assety[0]->expired_date)); ?>" disabled>

            </div>

        </div>

        <div class="row m-lg-1">
            <div class="col mt-2">
                <!-- Default input -->
                <label class="mb-2">Asset Location</label>

                <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="location_id" name="location_id" disabled>

                    <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(old('location_id',$assety[0]->location_id)==$loc->id): ?>
                    <option value="<?= $loc->id; ?>" selected><?= $loc->asset_HL_LL; ?>-<?= $loc->asset_loc_mp; ?>-<?= $loc->asset_loc_dkm; ?>- Room <?= $loc->asset_loc_dkm_room; ?></option>
                    <?php else: ?>
                    <option value="<?= $loc->id; ?>"><?= $loc->asset_HL_LL; ?>-<?= $loc->asset_loc_mp; ?>-<?= $loc->asset_loc_dkm; ?>- Room <?= $loc->asset_loc_dkm_room; ?></option>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>

        <div class="row m-lg-1">
            <div class="col mt-2">
                <label>Please provide MIS Id, If isn't fill with '0'</label>

            </div>
        </div>

        <div class="row m-lg-1">
            <!-- Grid column -->
            <div class="col-8 mt-1 mb-2">
                <input type="number" class="form-control <?php $__errorArgs = ['mis_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Asset MIS Id" id="mis_id" name="mis_id" value="<?php echo e(old('mis_id',$assety[0]->mis_id)); ?>" disabled>
                <?php $__errorArgs = ['mis_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


    </div>

</form>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Larapps\ymm\resources\views/dashboard/detail.blade.php ENDPATH**/ ?>