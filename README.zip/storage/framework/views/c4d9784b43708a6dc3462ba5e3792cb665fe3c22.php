

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">YMM PT FI Assets</h1>

</div>
<div>
    <a href="/dashboard/create" class="btn btn-primary mb-3">Add Assets +</a>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Asset ID</th>
                <th>Asset Name</th>
                <th>PIC</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><a href="/detail/<?= $asset->asset_id; ?>"><?= $asset->asset_id; ?></a></td>
                <td><?= $asset->asset_name; ?></td>
                <td><?= $asset->User->name; ?></td>
                <td style="background-color:<?= ($asset->asset_status->asset_status_name === "Available") ? '#adff2f' : '' ?>">
                    <?= $asset->asset_status->asset_status_name; ?>
                </td>
                <td>
                    <a href="" class="badge bg-info"><span data-feather="edit"></span></a>
                    <a href="" class="badge bg-warning"><span data-feather="trash-2"></span></a>

                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Larapps\ymm\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>