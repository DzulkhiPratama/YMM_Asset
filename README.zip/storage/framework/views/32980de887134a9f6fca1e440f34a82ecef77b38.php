<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand" href="#">YMM PT FI</a>

    <button class="navbar-toggler position-absolute px-0 d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
            <?php if(auth()->guard()->check()): ?>
            <form action="/logout" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="nav-link px-5 border-0" style=" background-color: transparent">
                    <!-- sudah ada relasi db antara auth dengan model user bawaan laravel -->
                    <?php echo e(auth()->user()->name); ?> <i class="bi bi-box-arrow-in-right"></i>
                </button>
            </form>


            <?php else: ?>
            <a class="nav-link px-5" href="/login">Sign In <i class="bi bi-box-arrow-in-left"></i></a>

            <?php endif; ?>

        </div>
    </div>

</header><?php /**PATH D:\Project\Larapps\ymm\resources\views/dashboard/layouts/header.blade.php ENDPATH**/ ?>