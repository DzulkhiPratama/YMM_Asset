
<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">YMM PT FI Assets Approval</h1>

</div>


<?php if(session()->has('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>

<?php elseif(session()->has('danger')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('danger')); ?>

</div>
<?php endif; ?>

<div class="card mb-4">
    <div class="card-header">Submitted Order</div>
    <div class="card-body">
        <?php if(auth()->guard()->check()): ?>
        <?php if( auth()->user()->role_id >= 1): ?>
        <a href="/transaction/create" class="btn btn-primary mb-3">Add Order +</a>
        <?php endif; ?>
        <?php endif; ?>

        <table id="apporderlist" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Asset ID</th>
                    <th>Asset Name</th>
                    <th>Requestor</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><a href="/transaction/<?php echo e($tr->order_id); ?>"><?= $tr->asset_type_Code; ?><?= $tr->asset_id; ?></a></td>
                    <td><?= $tr->asset_name; ?></td>
                    <td><?= $tr->name; ?></td>

                    <?php if($tr->adm_user_id == 0): ?>
                    <td style="background-color:#ffb347">
                        Waiting for Admin Check
                    </td>

                    <?php elseif($tr->adm_user_id !== 0): ?>

                    <?php if($tr->disapp_user_id !== 0 and $tr->return_user_id == 0): ?>
                    <td style="background-color:#da2c43">
                        Order Been Disapproved
                    </td>
                    <?php elseif($tr->app_user_id == 0): ?>
                    <td style="background-color:#da2c43">
                        Waiting for Approval
                    </td>
                    <?php elseif($tr->app_user_id !== 0 and $tr->return_user_id == 0): ?>
                    <td style="background-color:#da2c43">
                        Order been approved & Asset already out
                    </td>
                    <?php elseif($tr->app_user_id !== 0 and $tr->return_user_id !== 0): ?>
                    <td style="background-color:#adff2f">
                        Completed
                    </td>
                    <?php endif; ?>

                    <?php endif; ?>
                    <td>
                        <?php if(auth()->guard()->check()): ?>
                        <?php if($tr->disapp_user_id !== 0): ?>
                        <a><span data-feather="check-square"></span></a>
                        <a><span data-feather="trash-2"></span></a>

                        <?php elseif($tr->app_user_id !== 0 and $tr->return_user_id !== 0): ?>
                        <a><span data-feather="check-square"></span></a>
                        <a><span data-feather="trash-2"></span></a>

                        <?php elseif(auth()->user()->role_id >= 2 and $tr->return_user_id == 0 and $tr->disapp_user_id == 0): ?>
                        <a href="/transaction/<?php echo e($tr->order_id); ?>/edit" class="badge bg-info"><span data-feather="check-square"></span></a>

                        <form action="/transaction/<?php echo e($tr->order_id); ?>" method="post" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>

                            <button href="" class="badge bg-warning border-0" onclick="return confirm('Want to delete this order?')"><span data-feather="trash-2"></span></button>
                        </form>

                        <?php else: ?>
                        <!-- nothing to show when not adm -->
                        <a><span data-feather="check-square"></span></a>
                        <a><span data-feather="trash-2"></span></a>
                        <?php endif; ?>

                        <!-- bila tidak log in -->
                        <?php else: ?>
                        <a><span data-feather="check-square"></span></a>
                        <a><span data-feather="trash-2"></span></a>
                        <?php endif; ?>
                    </td>

                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Larapps\ymm\resources\views/transaction/index.blade.php ENDPATH**/ ?>