<?php

namespace App\Http\Controllers;

use App\Models\asset_type;
use Illuminate\Http\Request;

class AssetTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\asset_type  $asset_type
     * @return \Illuminate\Http\Response
     */
    public function show(asset_type $asset_type)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\asset_type  $asset_type
     * @return \Illuminate\Http\Response
     */
    public function edit(asset_type $asset_type)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\asset_type  $asset_type
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, asset_type $asset_type)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\asset_type  $asset_type
     * @return \Illuminate\Http\Response
     */
    public function destroy(asset_type $asset_type)
    {
        //
    }
}
