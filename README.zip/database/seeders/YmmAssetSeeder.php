<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class YmmAssetSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
